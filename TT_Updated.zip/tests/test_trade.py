from unittest import TestCase
from app import Trade


class TestTrade(TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass