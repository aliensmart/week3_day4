from unittest import TestCase
from app import util


class TestPosition(TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass