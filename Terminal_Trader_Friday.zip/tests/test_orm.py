from unittest import TestCase
from app import ORM


class TestORM(TestCase):
    """these should already exist from previous assigments, we should 
    be able to just copy and paste the same tests in here"""

    def setUp(self):
        pass

    def tearDown(self):
        pass
